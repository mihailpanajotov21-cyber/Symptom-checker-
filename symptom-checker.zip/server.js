// Симптом-чекър v0.2: търсене в медицински сайтове + запазени разговори.
// Локално: `npm run dev` (с .env). На хост: `npm start` и променливи от настройките му.
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3000;
const MODEL = process.env.MODEL || "claude-sonnet-5-5";
const API_KEY = process.env.ANTHROPIC_API_KEY;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "data");
const RETENTION_DAYS = Number(process.env.RETENTION_DAYS || 30);
const SEARCH_DOMAINS = (process.env.SEARCH_DOMAINS ||
  "medlineplus.gov,nhs.uk,who.int,mayoclinic.org,cdc.gov,clevelandclinic.org").split(",").map((s) => s.trim()).filter(Boolean);

fs.mkdirSync(DATA_DIR, { recursive: true });

const SYSTEM_PROMPT = `Ти си български помощник за първоначална ориентация по симптоми. Ти НЕ си лекар и НЕ поставяш диагнози.

Правила:
1. Отговаряй на български, кратко и ясно.
2. Ако информацията не стига, задай най-много 2-3 уточняващи въпроса (от кога, температура, възраст, хронични заболявания, затруднено дишане и т.н.). Докато задаваш въпроси, НЕ търси в интернет.
3. Когато имаш достатъчно данни за извод, потърси в уеб (на английски) и базирай извода на резултатите. Не измисляй факти, които не си намерил.
4. Формат на извода:
   **Най-вероятно:** ... (1-2 причини)
   **По-рядко:** ...
   **Какво можеш да направиш:** ... (общи мерки, без дозировки на лекарства)
   **Виж лекар, ако:** ... (конкретни тревожни признаци)
5. Никога не казвай "имаш [болест]". Казвай "симптомите са най-типични за...".
6. При опасни симптоми (болка в гърдите, затруднено дишане, загуба на съзнание, признаци на инсулт, силно кървене, тежка алергична реакция, мисли за самоубийство, висока температура при бебе) започни с "Обади се на 112 или отиди в спешно отделение." и не продължавай с обичайния формат.
7. Не предписвай лекарства и дозировки. Ако питат, насочи към лекар или фармацевт.
8. Ако въпросът не е за здраве, учтиво откажи.
9. Бъди спокоен и подкрепящ, без да плашиш излишно.`;

// ---- Спешни фрази (малки букви, без \b заради кирилицата) ----
const MEDICAL = [
  /болк[аи] в гърд/, /стягане в гърд/, /натиск в гърд/, /болк[аи] в лявата ръка/,
  /не мога да дишам/, /трудно дишам/, /затруднено дишане/, /задуш[аа]вам се/, /задух/, /спира ми дъха/,
  /загубих съзнание/, /губя съзнание/, /припад/, /безсъзнание/, /не реагира/,
  /инсулт/, /изкривено лице/, /увиснало лице/, /не мога да говоря/, /заплита ми се езика/, /парализ/, /отнема ми се/,
  /силно кървене/, /не спира да кърви/, /повръщам кръв/, /кашлям кръв/, /кръв в повърнатото/, /черни изпражнения/,
  /алергична реакция/, /подуха ми (гърлото|езика|устата)/, /анафилакси/,
  /конвулси/, /гърч/, /епилептичен/,
  /предозира/, /отрови/, /погълнах (химикал|белина|почистващ)/,
];
const CRISIS = [/самоубий/, /да се убия/, /искам да умра/, /не искам да живея/, /да се самонаранявам/, /самонаранява/];

const EMERGENCY_REPLY = "Обади се на 112 или отиди в спешно отделение. Описаното може да е спешно и не бива да чака онлайн съвет.";
const CRISIS_REPLY = "Съжалявам, че ти е толкова тежко. Моля те, обади се на 112 или говори веднага с близък човек, който може да е до теб. Ти заслужаваш помощ и не си сам.";

function checkEmergency(text) {
  const t = text.toLowerCase();
  if (CRISIS.some((r) => r.test(t))) return CRISIS_REPLY;
  if (MEDICAL.some((r) => r.test(t))) return EMERGENCY_REPLY;
  return null;
}

// ---- Запазване на разговорите (JSON файл на разговор) ----
const ID_RE = /^[0-9a-f-]{36}$/;
const fileOf = (id) => path.join(DATA_DIR, `${id}.json`);
function load(id) {
  try { return JSON.parse(fs.readFileSync(fileOf(id), "utf8")); } catch { return { id, messages: [] }; }
}
const save = (c) => fs.writeFileSync(fileOf(c.id), JSON.stringify(c));

function sweepOld() {
  const limit = Date.now() - RETENTION_DAYS * 86_400_000;
  for (const f of fs.readdirSync(DATA_DIR)) {
    const p = path.join(DATA_DIR, f);
    if (f.endsWith(".json") && fs.statSync(p).mtimeMs < limit) fs.unlinkSync(p);
  }
}
sweepOld();
setInterval(sweepOld, 86_400_000);

// ---- Claude + търсене в уеб ----
async function callApi(messages) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "content-type": "application/json", "x-api-key": API_KEY, "anthropic-version": "2023-06-01" },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: 1200,
      system: SYSTEM_PROMPT,
      messages,
      tools: [{ type: "web_search_20250305", name: "web_search", max_uses: 3, allowed_domains: SEARCH_DOMAINS }],
    }),
  });
  if (!res.ok) throw new Error(`API ${res.status}: ${await res.text()}`);
  return res.json();
}

async function askClaude(messages) {
  let msgs = messages, text = "";
  const sources = new Map();
  for (let i = 0; i < 3; i++) {
    const data = await callApi(msgs);
    for (const b of data.content) {
      if (b.type !== "text") continue;
      text += b.text;
      for (const c of b.citations || []) if (/^https?:\/\//.test(c.url || "")) sources.set(c.url, c.title || c.url);
    }
    if (data.stop_reason !== "pause_turn") break;
    msgs = [...msgs, { role: "assistant", content: data.content }];
  }
  return { reply: text.trim(), sources: [...sources].map(([url, title]) => ({ url, title })) };
}

// ---- HTTP ----
const hits = new Map();
function limited(ip) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < 60_000);
  arr.push(now); hits.set(ip, arr);
  return arr.length > 20;
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = "";
    req.on("data", (c) => { raw += c; if (raw.length > 20_000) { reject(new Error("too large")); req.destroy(); } });
    req.on("end", () => resolve(raw));
    req.on("error", reject);
  });
}
const MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css" };

http.createServer(async (req, res) => {
  const send = (code, obj) => { res.writeHead(code, { "content-type": "application/json" }); res.end(JSON.stringify(obj)); };
  const url = req.url.split("?")[0];
  const convMatch = url.match(/^\/api\/conv\/([0-9a-f-]{36})$/);

  try {
    if (convMatch && req.method === "GET") return send(200, load(convMatch[1]));
    if (convMatch && req.method === "DELETE") {
      try { fs.unlinkSync(fileOf(convMatch[1])); } catch {}
      return send(200, { ok: true });
    }

    if (req.method === "POST" && url === "/api/chat") {
      if (limited(req.socket.remoteAddress)) return send(429, { error: "Твърде много заявки. Опитай след минута." });

      const { id, text } = JSON.parse(await readBody(req));
      if (!ID_RE.test(id || "") || typeof text !== "string" || !text.trim()) return send(400, { error: "Невалидна заявка." });
      const msg = text.trim().slice(0, 2000);

      const conv = load(id);
      const userMsg = { role: "user", content: msg, t: Date.now() };

      const alert = checkEmergency(msg);
      let botMsg;
      if (alert) {
        botMsg = { role: "assistant", content: alert, emergency: true, t: Date.now() };
      } else {
        if (!API_KEY) return send(500, { error: "Липсва ANTHROPIC_API_KEY." });
        // Само последните 19 съобщения (започват с потребител) + новото
        const history = [...conv.messages, userMsg].slice(-19).map((m) => ({ role: m.role, content: m.content }));
        const { reply, sources } = await askClaude(history);
        botMsg = { role: "assistant", content: reply || "Не успях да формулирам отговор. Опитай пак.", sources, t: Date.now() };
      }
      conv.messages.push(userMsg, botMsg);
      save(conv);
      return send(200, botMsg);
    }
  } catch (e) {
    console.error(e);
    return send(500, { error: "Нещо се обърка. Опитай пак." });
  }

  if (req.method === "GET") {
    const file = url === "/" ? "index.html" : path.basename(url);
    const full = path.join(__dirname, "public", file);
    if (fs.existsSync(full)) {
      res.writeHead(200, { "content-type": MIME[path.extname(full)] || "text/plain" });
      return fs.createReadStream(full).pipe(res);
    }
  }
  res.writeHead(404); res.end("Not found");
}).listen(PORT, () => console.log(`http://localhost:${PORT}`));
